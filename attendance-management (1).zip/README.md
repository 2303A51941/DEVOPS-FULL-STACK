# Student Attendance Management System

React + Vite frontend assignment implementing:

- Header component
- StudentList component
- StudentCard component
- Attendance component
- Summary component
- Props between parent and child components
- useState attendance management
- Present/Absent buttons
- Dynamic attendance percentage
- Eligible / Not Eligible conditional rendering
- Search students
- Reset Attendance
- Present/absent summary statistics
- Low-attendance highlighting

## Run

```bash
npm install
npm run dev
```

Open the local URL shown by Vite, usually:

http://localhost:5173/
