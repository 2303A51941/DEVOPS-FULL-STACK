import { useMemo, useState } from "react";
import Header from "./components/Header";
import StudentList from "./components/StudentList";
import Summary from "./components/Summary";

const initialStudents = [
  { id: 1, name: "Aarav Kumar", rollNumber: "23A001", branch: "CSE", attendance: 86 },
  { id: 2, name: "Priya Sharma", rollNumber: "23A002", branch: "ECE", attendance: 72 },
  { id: 3, name: "Rahul Reddy", rollNumber: "23A003", branch: "CSE", attendance: 91 },
  { id: 4, name: "Sneha Patel", rollNumber: "23A004", branch: "IT", attendance: 68 },
  { id: 5, name: "Vikram Singh", rollNumber: "23A005", branch: "EEE", attendance: 79 },
  { id: 6, name: "Ananya Rao", rollNumber: "23A006", branch: "AIML", attendance: 74 }
];

function App() {
  const [students, setStudents] = useState(initialStudents);
  const [search, setSearch] = useState("");

  const updateAttendance = (id, status) => {
    setStudents((current) =>
      current.map((student) => {
        if (student.id !== id) return student;

        // Each faculty action represents one attendance record.
        // Present increases the percentage by 1; Absent decreases it by 1.
        const change = status === "present" ? 1 : -1;
        const attendance = Math.max(0, Math.min(100, student.attendance + change));

        return { ...student, attendance };
      })
    );
  };

  const resetAttendance = () => setStudents(initialStudents);

  const filteredStudents = useMemo(() => {
    const query = search.toLowerCase().trim();
    if (!query) return students;

    return students.filter(
      (student) =>
        student.name.toLowerCase().includes(query) ||
        student.rollNumber.toLowerCase().includes(query) ||
        student.branch.toLowerCase().includes(query)
    );
  }, [students, search]);

  const summary = useMemo(() => {
    const total = students.length;
    const eligible = students.filter((student) => student.attendance >= 75).length;
    const notEligible = total - eligible;
    const average =
      total === 0
        ? 0
        : students.reduce((sum, student) => sum + student.attendance, 0) / total;

    return { total, eligible, notEligible, average };
  }, [students]);

  return (
    <div className="app">
      <Header />

      <main className="container">
        <section className="hero">
          <div>
            <p className="eyebrow">Faculty Dashboard</p>
            <h1>Student Attendance Dashboard</h1>
            <p>
              Manage student attendance using React state, props, reusable
              components, and conditional rendering.
            </p>
          </div>

          <button className="reset-btn" onClick={resetAttendance}>
            Reset Attendance
          </button>
        </section>

        <Summary
          total={summary.total}
          eligible={summary.eligible}
          notEligible={summary.notEligible}
          average={summary.average}
        />

        <section className="toolbar">
          <div>
            <h2>Students</h2>
            <p>Mark each student as Present or Absent.</p>
          </div>

          <input
            type="search"
            placeholder="Search by name, roll number or branch..."
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            aria-label="Search students"
          />
        </section>

        <StudentList
          students={filteredStudents}
          onAttendanceChange={updateAttendance}
        />
      </main>
    </div>
  );
}

export default App;