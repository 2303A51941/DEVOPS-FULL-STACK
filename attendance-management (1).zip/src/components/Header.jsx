function Header() {
  return (
    <header className="header">
      <div className="header-inner">
        <div className="logo">🎓</div>
        <div>
          <h2>Student Attendance Management System</h2>
          <p>College Faculty Portal</p>
        </div>
      </div>
    </header>
  );
}

export default Header;