function Summary({ total, eligible, notEligible, average }) {
  return (
    <section className="summary-grid">
      <div className="summary-card">
        <span>Total Students</span>
        <strong>{total}</strong>
      </div>

      <div className="summary-card present-summary">
        <span>Eligible (≥75%)</span>
        <strong>{eligible}</strong>
      </div>

      <div className="summary-card absent-summary">
        <span>Not Eligible (&lt;75%)</span>
        <strong>{notEligible}</strong>
      </div>

      <div className="summary-card">
        <span>Average Attendance</span>
        <strong>{average.toFixed(1)}%</strong>
      </div>
    </section>
  );
}

export default Summary;