function Attendance({ studentId, attendance, onAttendanceChange }) {
  return (
    <div className="attendance">
      <div className="attendance-row">
        <span>Attendance</span>
        <strong>{attendance}%</strong>
      </div>

      <div className="progress">
        <div
          className="progress-bar"
          style={{ width: `${attendance}%` }}
        />
      </div>

      <div className="actions">
        <button
          className="present-btn"
          onClick={() => onAttendanceChange(studentId, "present")}
        >
          Present
        </button>
        <button
          className="absent-btn"
          onClick={() => onAttendanceChange(studentId, "absent")}
        >
          Absent
        </button>
      </div>
    </div>
  );
}

export default Attendance;