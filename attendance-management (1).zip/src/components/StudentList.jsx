import StudentCard from "./StudentCard";

function StudentList({ students, onAttendanceChange }) {
  if (students.length === 0) {
    return <div className="empty">No students found.</div>;
  }

  return (
    <section className="student-grid">
      {students.map((student) => (
        <StudentCard
          key={student.id}
          student={student}
          onAttendanceChange={onAttendanceChange}
        />
      ))}
    </section>
  );
}

export default StudentList;