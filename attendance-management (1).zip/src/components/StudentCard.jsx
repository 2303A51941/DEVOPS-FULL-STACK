import Attendance from "./Attendance";

function StudentCard({ student, onAttendanceChange }) {
  const eligible = student.attendance >= 75;

  return (
    <article className={`student-card ${!eligible ? "low-attendance" : ""}`}>
      <div className="student-top">
        <div className="avatar">{student.name.charAt(0)}</div>
        <div>
          <h3>{student.name}</h3>
          <p>{student.rollNumber} · {student.branch}</p>
        </div>
      </div>

      <Attendance
        studentId={student.id}
        attendance={student.attendance}
        onAttendanceChange={onAttendanceChange}
      />

      <div className={`eligibility ${eligible ? "eligible" : "not-eligible"}`}>
        {eligible ? "Eligible" : "Not Eligible"}
      </div>
    </article>
  );
}

export default StudentCard;